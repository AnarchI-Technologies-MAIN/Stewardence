"""Immutable deterministic assessment snapshots."""
