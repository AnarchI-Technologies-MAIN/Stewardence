"""Email-based AgentLedger identity."""
