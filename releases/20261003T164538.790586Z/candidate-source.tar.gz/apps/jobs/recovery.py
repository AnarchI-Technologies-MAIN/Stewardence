"""Admission policy for automated recovery: unknown failures require review."""
import httpx
from botocore.exceptions import EndpointConnectionError, ConnectionClosedError, ReadTimeoutError
from django.core.exceptions import PermissionDenied, ValidationError, ImproperlyConfigured


class RetryableOperationError(RuntimeError):
    """A bounded, repeatable operation failed transiently without changing authority."""


def permits_retry(error: Exception) -> bool:
    if isinstance(error, (PermissionDenied, ValidationError, ImproperlyConfigured, ValueError)):
        return False
    seen = set()
    current = error
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        if isinstance(current, (RetryableOperationError, httpx.TimeoutException,
                                httpx.ConnectError, httpx.ReadError,
                                EndpointConnectionError, ConnectionClosedError, ReadTimeoutError)):
            return True
        current = current.__cause__
    return False
