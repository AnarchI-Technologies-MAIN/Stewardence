import hashlib
import rfc8785
from .models import RecoveryReceipt


def record_recovery_receipt(job, outcome, *, reason_code="", fingerprint="", using="default"):
    if outcome not in {"completed", "retry", "review"}:
        raise ValueError("Unsupported recovery outcome")
    if reason_code not in {"", "job_execution_failed", "job_requires_review"}:
        raise ValueError("Unsupported recovery reason")
    payload = {"schema":"stewardence.recovery.v1", "job_id":str(job.id),
        "organization_id":str(job.organization_id), "operation":job.job_type,
        "attempt":job.attempts, "outcome":outcome,
        "input_sha256":hashlib.sha256(rfc8785.dumps(job.payload)).hexdigest(),
        "reason_code":reason_code, "failure_fingerprint":fingerprint}
    digest = hashlib.sha256(rfc8785.dumps(payload)).hexdigest()
    receipt, created = RecoveryReceipt.objects.using(using).get_or_create(
        organization_id=job.organization_id, job_id=job.id,
        attempt=job.attempts, outcome=outcome, defaults={"payload":payload, "sha256":digest})
    if not created and (receipt.payload != payload or receipt.sha256 != digest):
        raise ValueError("Recovery receipt conflicts with recorded outcome")
    return receipt


def verify_recovery_receipt(receipt):
    payload = receipt.payload
    if not isinstance(payload, dict):
        return False
    expected = {"schema":"stewardence.recovery.v1", "job_id":str(receipt.job_id),
        "organization_id":str(receipt.organization_id), "attempt":receipt.attempt,
        "outcome":receipt.outcome}
    if any(payload.get(key) != value for key, value in expected.items()):
        return False
    try:
        return hashlib.sha256(rfc8785.dumps(payload)).hexdigest() == receipt.sha256
    except (TypeError, ValueError):
        return False
