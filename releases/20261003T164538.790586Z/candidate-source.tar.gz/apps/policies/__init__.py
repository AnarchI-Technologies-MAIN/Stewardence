"""Deterministic policy evaluation."""
