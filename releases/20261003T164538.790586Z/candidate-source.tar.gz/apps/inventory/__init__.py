"""Tenant-owned software inventory."""
