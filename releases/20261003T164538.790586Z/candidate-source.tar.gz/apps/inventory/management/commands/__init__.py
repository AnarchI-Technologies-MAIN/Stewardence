"""Inventory command implementations."""
