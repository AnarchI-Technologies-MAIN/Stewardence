"""Inventory management commands."""
