"""Inventory schema migrations."""
