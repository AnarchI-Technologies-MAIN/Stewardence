"""Catalog command implementations."""
