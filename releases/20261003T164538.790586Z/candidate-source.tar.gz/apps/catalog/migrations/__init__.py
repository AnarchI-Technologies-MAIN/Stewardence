"""Catalog schema migrations."""
