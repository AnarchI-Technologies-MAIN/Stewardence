"""Small deterministic product catalog."""
