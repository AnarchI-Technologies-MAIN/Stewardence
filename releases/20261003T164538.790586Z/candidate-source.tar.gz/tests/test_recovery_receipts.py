import copy
from uuid import uuid4
import pytest
from django.db import DatabaseError, transaction
from agentledger.tenancy.context import tenant_transaction
from apps.jobs.models import BackgroundJob, RecoveryReceipt
from apps.jobs.queue import enqueue_job
from apps.jobs.worker import drain_queue
from apps.jobs.receipts import verify_recovery_receipt
from apps.organizations.models import Organization

pytestmark = pytest.mark.django_db(transaction=True, databases="__all__")


def test_worker_completion_receipt_is_bound_immutable_and_tenant_private():
    organization = Organization.objects.create(name="Receipt firm")
    other = Organization.objects.create(name="Other receipt firm")
    job = enqueue_job(organization_id=organization.id,
        job_type=BackgroundJob.Type.REPORT_GENERATION, payload={"report_id":str(uuid4())})
    class Handler:
        def prepare(self, job): return None
        def execute_external(self, prepared, heartbeat): return None
        def persist(self, job, result): return None
    drain_queue("receipt-worker", lambda kind: Handler(), using="worker_runtime", max_jobs=1)
    receipt = RecoveryReceipt.objects.get(job=job)
    assert verify_recovery_receipt(receipt)
    assert receipt.outcome == "completed"
    with tenant_transaction(other.id, using="app_runtime"):
        assert not RecoveryReceipt.objects.using("app_runtime").filter(id=receipt.id).exists()
    with tenant_transaction(organization.id, using="app_runtime"):
        assert RecoveryReceipt.objects.using("app_runtime").filter(id=receipt.id).exists()
    with pytest.raises(DatabaseError), transaction.atomic():
        RecoveryReceipt.objects.filter(id=receipt.id).update(payload={})
    with pytest.raises(DatabaseError), transaction.atomic():
        RecoveryReceipt.objects.filter(id=receipt.id).delete()
    changed = copy.copy(receipt)
    changed.organization_id = other.id
    assert not verify_recovery_receipt(changed)
