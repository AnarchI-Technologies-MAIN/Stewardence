import httpx
import pytest
from django.core.exceptions import PermissionDenied, ImproperlyConfigured
from apps.jobs.recovery import permits_retry
from apps.reports.render_client import HTTPReportRenderer, ReportRenderError


@pytest.mark.parametrize("error", [ValueError("bad payload"), PermissionDenied("wrong firm"),
    ImproperlyConfigured("missing configuration"), RuntimeError("unclassified")])
def test_unknown_or_authority_failures_require_review(error):
    assert not permits_retry(error)


def test_wrapped_transport_timeout_is_retryable_but_permission_denial_is_not():
    cause = httpx.ReadTimeout("private transport details")
    wrapped = ReportRenderError("request failed")
    wrapped.__cause__ = cause
    assert permits_retry(wrapped)
    denied = PermissionDenied("scope unresolved")
    denied.__cause__ = cause
    assert not permits_retry(denied)


@pytest.mark.parametrize("status,retry", [(400,False),(401,False),(403,False),(429,True),(503,True)])
def test_renderer_status_admits_only_bounded_transient_recovery(status, retry):
    renderer = HTTPReportRenderer(base_url="http://renderer", transport=httpx.MockTransport(
        lambda request: httpx.Response(status, text="provider secret must never propagate")))
    with pytest.raises(ReportRenderError) as error:
        renderer.render({})
    assert permits_retry(error.value) is retry
    assert "provider secret" not in str(error.value)
